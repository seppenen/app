

import React, {createContext } from 'react';

export const Context = createContext();

/* class dataObj extends Component {

state={
    data:true
}
toggle=()=>{
  console.log("toggle()")}
    render() {
        return (
            <Data.Provider value={{...this.state}}> 
            {this.props.children}
            </Data.Provider>
        );
    }
} 

export default dataObj;
*/
